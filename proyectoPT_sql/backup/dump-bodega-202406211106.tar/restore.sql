--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE bodega;
--
-- Name: bodega; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE bodega WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Spain.1252';


ALTER DATABASE bodega OWNER TO postgres;

\connect bodega

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE bodega; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE bodega IS 'BD utilizada en la prueba técnica';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bodega; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bodega (
    bodega_id bigint NOT NULL,
    codigo_bodega character varying NOT NULL,
    nombre_bodega character varying NOT NULL,
    direccion_bodega character varying NOT NULL,
    dotacion_bodega integer NOT NULL,
    estado_bodega boolean DEFAULT true NOT NULL,
    registro_creacion_bodega timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.bodega OWNER TO postgres;

--
-- Name: TABLE bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.bodega IS 'Tabla que contiene las bodegas del sistema';


--
-- Name: COLUMN bodega.bodega_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.bodega_id IS 'Identificador primario de la tabla Bodega';


--
-- Name: COLUMN bodega.codigo_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.codigo_bodega IS 'código identificador de la bodega';


--
-- Name: COLUMN bodega.nombre_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.nombre_bodega IS 'Nombre de la bodega';


--
-- Name: COLUMN bodega.direccion_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.direccion_bodega IS 'Dirección correspondiente de la bodega';


--
-- Name: COLUMN bodega.dotacion_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.dotacion_bodega IS 'Valor que indica la cantidad de personas que trabajan en la bodega';


--
-- Name: COLUMN bodega.estado_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.estado_bodega IS 'estado de la bodega (activada/desactivada)';


--
-- Name: COLUMN bodega.registro_creacion_bodega; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega.registro_creacion_bodega IS 'Fecha de creación del registro de la bodega';


--
-- Name: bodega_bodega_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bodega_bodega_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bodega_bodega_id_seq OWNER TO postgres;

--
-- Name: bodega_bodega_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bodega_bodega_id_seq OWNED BY public.bodega.bodega_id;


--
-- Name: bodega_funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bodega_funcionario (
    id_bod_func bigint NOT NULL,
    bf_bodega_id bigint NOT NULL,
    bf_if_funcionario bigint NOT NULL
);


ALTER TABLE public.bodega_funcionario OWNER TO postgres;

--
-- Name: TABLE bodega_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.bodega_funcionario IS 'Tabla que contiene la conexión múltiple de funcionarios en las bodegas';


--
-- Name: COLUMN bodega_funcionario.id_bod_func; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega_funcionario.id_bod_func IS 'Identificador primeraio de la tabla bodega_funcionario';


--
-- Name: COLUMN bodega_funcionario.bf_bodega_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega_funcionario.bf_bodega_id IS 'Identificador foráneo de la tabla bodega';


--
-- Name: COLUMN bodega_funcionario.bf_if_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.bodega_funcionario.bf_if_funcionario IS 'Identificador de la tabla funcionario, el cual puede ser múltiple';


--
-- Name: bodega_funcionario_id_bod_func_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bodega_funcionario_id_bod_func_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bodega_funcionario_id_bod_func_seq OWNER TO postgres;

--
-- Name: bodega_funcionario_id_bod_func_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bodega_funcionario_id_bod_func_seq OWNED BY public.bodega_funcionario.id_bod_func;


--
-- Name: funcionario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.funcionario (
    funcionario_id bigint NOT NULL,
    rut_funcionario character varying NOT NULL,
    nombre_funcionario character varying NOT NULL,
    appat_funcionario character varying NOT NULL,
    apmat_funcionario character varying NOT NULL,
    direccion_funcionario character varying NOT NULL,
    telefono_funcionario integer NOT NULL
);


ALTER TABLE public.funcionario OWNER TO postgres;

--
-- Name: TABLE funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.funcionario IS 'Tabla que almacena los funcionarios del sistema';


--
-- Name: COLUMN funcionario.funcionario_id; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.funcionario_id IS 'Identificador primario de la tabla funcionario';


--
-- Name: COLUMN funcionario.rut_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.rut_funcionario IS 'Rut correspondiente al funcionario';


--
-- Name: COLUMN funcionario.nombre_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.nombre_funcionario IS 'Nombre del funcionario';


--
-- Name: COLUMN funcionario.appat_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.appat_funcionario IS 'Apellido paterno del funcionario';


--
-- Name: COLUMN funcionario.apmat_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.apmat_funcionario IS 'Apellido materno del funcionario';


--
-- Name: COLUMN funcionario.direccion_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.direccion_funcionario IS 'Dirección proporcionada por el funcionario';


--
-- Name: COLUMN funcionario.telefono_funcionario; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public.funcionario.telefono_funcionario IS 'Número de contacto del funcionario';


--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.funcionario_id_funcionario_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.funcionario_id_funcionario_seq OWNER TO postgres;

--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.funcionario_id_funcionario_seq OWNED BY public.funcionario.funcionario_id;


--
-- Name: bodega bodega_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega ALTER COLUMN bodega_id SET DEFAULT nextval('public.bodega_bodega_id_seq'::regclass);


--
-- Name: bodega_funcionario id_bod_func; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega_funcionario ALTER COLUMN id_bod_func SET DEFAULT nextval('public.bodega_funcionario_id_bod_func_seq'::regclass);


--
-- Name: funcionario funcionario_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario ALTER COLUMN funcionario_id SET DEFAULT nextval('public.funcionario_id_funcionario_seq'::regclass);


--
-- Data for Name: bodega; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bodega (bodega_id, codigo_bodega, nombre_bodega, direccion_bodega, dotacion_bodega, estado_bodega, registro_creacion_bodega) FROM stdin;
\.
COPY public.bodega (bodega_id, codigo_bodega, nombre_bodega, direccion_bodega, dotacion_bodega, estado_bodega, registro_creacion_bodega) FROM '$$PATH$$/4805.dat';

--
-- Data for Name: bodega_funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bodega_funcionario (id_bod_func, bf_bodega_id, bf_if_funcionario) FROM stdin;
\.
COPY public.bodega_funcionario (id_bod_func, bf_bodega_id, bf_if_funcionario) FROM '$$PATH$$/4807.dat';

--
-- Data for Name: funcionario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.funcionario (funcionario_id, rut_funcionario, nombre_funcionario, appat_funcionario, apmat_funcionario, direccion_funcionario, telefono_funcionario) FROM stdin;
\.
COPY public.funcionario (funcionario_id, rut_funcionario, nombre_funcionario, appat_funcionario, apmat_funcionario, direccion_funcionario, telefono_funcionario) FROM '$$PATH$$/4803.dat';

--
-- Name: bodega_bodega_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bodega_bodega_id_seq', 11, true);


--
-- Name: bodega_funcionario_id_bod_func_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bodega_funcionario_id_bod_func_seq', 29, true);


--
-- Name: funcionario_id_funcionario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.funcionario_id_funcionario_seq', 5, true);


--
-- Name: bodega_funcionario bodega_funcionario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega_funcionario
    ADD CONSTRAINT bodega_funcionario_pk PRIMARY KEY (id_bod_func);


--
-- Name: bodega bodega_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega
    ADD CONSTRAINT bodega_unique UNIQUE (codigo_bodega);


--
-- Name: bodega bodegas_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega
    ADD CONSTRAINT bodegas_pk PRIMARY KEY (bodega_id);


--
-- Name: funcionario funcionario_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.funcionario
    ADD CONSTRAINT funcionario_pk PRIMARY KEY (funcionario_id);


--
-- Name: bodega_funcionario bodega_funcionario_bodega_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega_funcionario
    ADD CONSTRAINT bodega_funcionario_bodega_fk FOREIGN KEY (bf_bodega_id) REFERENCES public.bodega(bodega_id);


--
-- Name: bodega_funcionario bodega_funcionario_funcionario_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bodega_funcionario
    ADD CONSTRAINT bodega_funcionario_funcionario_fk FOREIGN KEY (bf_if_funcionario) REFERENCES public.funcionario(funcionario_id);


--
-- PostgreSQL database dump complete
--

